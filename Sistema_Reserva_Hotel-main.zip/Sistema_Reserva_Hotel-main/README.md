
# Diseño de Software para Sistema de Reservas de Hoteles.
## Materia: Ingeniería de Software.
## Integrantes:
1. David Paredes.
2. Abraham Jiménez.
3. Roberth Solórzano.
4. Diego Ortiz.
5. Jordy Loor.

### Framework utilizado (Django):
![django](https://github.com/user-attachments/assets/2b5c3f0c-9dfb-4d1f-b246-74d94756bc82)

### Pruebas unitarias al software desarrollado (Coverage.py):
![coverage](https://github.com/user-attachments/assets/17d933d4-5379-4511-b17d-7941bcfc77d7)


