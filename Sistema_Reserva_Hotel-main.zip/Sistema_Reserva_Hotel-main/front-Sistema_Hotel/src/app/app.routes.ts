<<<<<<< HEAD
import { Routes } from '@angular/router';

export const routes: Routes = [];
=======
import { Routes } from '@angular/router';

export const routes: Routes = [];
>>>>>>> 85a41a752e5d872c905cb18025fab730ae60ee25
